import { HttpClient } from '@angular/common/http';
import { Component,OnInit} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-modulemaster',
  templateUrl: './modulemaster.component.html',
  styleUrls: ['./modulemaster.component.css']
})
export class ModulemasterComponent implements OnInit{
  courses:any=[];
  courseName:any="";
  moduleName : string ="";
  constructor(private http:HttpClient, private router: Router)
  {

  }

  ngOnInit(): void {
    this.http.get("http://localhost:3000/admin/getAllCourse").subscribe((data:any)=>{
      console.log(data.allCourses);
       this.courses=data.allCourses;
    });
   }

  AddModule()
  {
  console.log("course name is " + this.courseName)
  console.log("Module name is " + this.moduleName )
  let bodydata ={
    courseName:this.courseName,
    moduleName :this.moduleName 
  };

  console.log(bodydata);
  
  this.http.post("http://localhost:3000/admin/addModule", bodydata).subscribe(  (resultData: any) => {
        console.log(resultData);
        console.log(resultData.message);
        console.log(resultData.status);
        
      });

    
  }

}
